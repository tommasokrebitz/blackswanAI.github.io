import React from 'react';
import { Zap, Bot, TrendingUp, Cpu } from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: Zap,
      title: 'Workflow Automation',
      description: 'Slash hours into minutes',
      details: 'Eliminate repetitive tasks and streamline your operations with intelligent automation solutions.'
    },
    {
      icon: Bot,
      title: 'AI Assistants & Chatbots',
      description: 'Always-on engagement',
      details: '24/7 customer support and engagement through advanced AI-powered conversational interfaces.'
    },
    {
      icon: TrendingUp,
      title: 'Predictive Analytics',
      description: 'Anticipate trends before they happen',
      details: 'Transform your data into future insights and stay ahead of market changes with AI predictions.'
    },
    {
      icon: Cpu,
      title: 'Custom AI Solutions',
      description: 'Tailored intelligence for your business',
      details: 'Bespoke AI implementations designed specifically for your unique business challenges and goals.'
    }
  ];

  return (
    <section id="services" className="py-24 px-6 relative">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-purple-400 neon-text mb-6">
            What Our AI Solutions Can Do For You
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Harness the power of artificial intelligence to transform your business operations
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <div 
              key={index}
              className="group relative bg-black border-2 border-purple-500/30 rounded-xl p-8 hover:border-purple-500 transition-all duration-500 hover:transform hover:scale-105 overflow-hidden"
            >
              {/* Neon glow effect */}
              <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 to-blue-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              
              <div className="relative z-10">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-blue-500 rounded-lg flex items-center justify-center mb-6 group-hover:animate-pulse">
                  <service.icon className="w-8 h-8 text-white" />
                </div>
                
                <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-purple-300 transition-colors duration-300">
                  {service.title}
                </h3>
                
                <p className="text-lg text-purple-400 font-semibold mb-4">
                  {service.description}
                </p>
                
                <p className="text-gray-300 group-hover:text-white transition-colors duration-300">
                  {service.details}
                </p>
              </div>

              {/* Animated border */}
              <div className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                <div className="absolute inset-0 rounded-xl border-2 border-purple-500 animate-pulse"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;