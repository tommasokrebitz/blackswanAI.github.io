import React from 'react';
import { Zap, Calendar } from 'lucide-react';

const CallToAction = () => {
  const handleScheduleCall = () => {
    window.location.href = 'mailto:tommaso.krebitz@gmail.com?subject=Strategy Session Request&body=Hi, I would like to schedule a free strategy session to discuss AI automation for my business.';
  };

  return (
    <section className="py-24 px-6 relative overflow-hidden">
      <div className="max-w-5xl mx-auto text-center relative z-10">
        <div className="mb-12">
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-6">
            Move{' '}
            <span className="text-purple-400 neon-text">Faster</span>.{' '}
            Think{' '}
            <span className="text-blue-400 neon-text">Smarter</span>.
          </h2>
          
          <p className="text-xl md:text-2xl text-gray-300 mb-12">
            Plug your business into the future today.
          </p>
        </div>

        <div className="relative">
          <button 
            onClick={handleScheduleCall}
            className="group px-12 py-6 bg-transparent border-2 border-purple-500 text-white text-xl md:text-2xl font-semibold rounded-lg hover:bg-purple-500 transition-all duration-300 transform hover:scale-105 neon-glow relative overflow-hidden"
          >
            <span className="relative z-10 flex items-center gap-4">
              <Zap className="w-8 h-8 group-hover:animate-pulse" />
              Schedule Your Free Strategy Session
              <Calendar className="w-8 h-8 group-hover:animate-bounce" />
            </span>
            <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-blue-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          </button>

          {/* Decorative elements */}
          <div className="absolute -top-4 -left-4 w-8 h-8 border border-purple-500/50 rounded-full animate-ping"></div>
          <div className="absolute -bottom-4 -right-4 w-6 h-6 border border-blue-500/50 rounded-full animate-ping animation-delay-1000"></div>
        </div>

        <p className="text-gray-400 mt-8 text-lg">
          No commitment. Just insights. Let's explore what's possible.
        </p>
      </div>

      {/* Background Lightning Streaks */}
      <div className="absolute top-0 left-1/4 w-px h-full bg-gradient-to-b from-transparent via-purple-500/30 to-transparent animate-pulse"></div>
      <div className="absolute top-0 right-1/4 w-px h-full bg-gradient-to-b from-transparent via-blue-500/30 to-transparent animate-pulse animation-delay-1000"></div>
    </section>
  );
};

export default CallToAction;