import React from 'react';

const AnimatedBackground = () => {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {/* Lightning Streaks */}
      <div className="absolute top-0 left-1/6 w-px h-full bg-gradient-to-b from-transparent via-purple-500/20 to-transparent animate-pulse"></div>
      <div className="absolute top-0 left-2/6 w-px h-full bg-gradient-to-b from-transparent via-blue-500/15 to-transparent animate-pulse animation-delay-500"></div>
      <div className="absolute top-0 left-3/6 w-px h-full bg-gradient-to-b from-transparent via-purple-500/10 to-transparent animate-pulse animation-delay-1000"></div>
      <div className="absolute top-0 left-4/6 w-px h-full bg-gradient-to-b from-transparent via-blue-500/20 to-transparent animate-pulse animation-delay-1500"></div>
      <div className="absolute top-0 left-5/6 w-px h-full bg-gradient-to-b from-transparent via-purple-500/15 to-transparent animate-pulse animation-delay-2000"></div>

      {/* Floating Particles */}
      <div className="absolute top-1/4 left-10 w-2 h-2 bg-purple-500 rounded-full animate-float opacity-60"></div>
      <div className="absolute top-1/3 right-16 w-1 h-1 bg-blue-500 rounded-full animate-float-delay opacity-50"></div>
      <div className="absolute bottom-1/4 left-1/4 w-1.5 h-1.5 bg-pink-500 rounded-full animate-float opacity-40"></div>
      <div className="absolute bottom-1/3 right-1/4 w-2 h-2 bg-purple-400 rounded-full animate-float-delay opacity-60"></div>
      <div className="absolute top-1/2 left-1/2 w-1 h-1 bg-blue-400 rounded-full animate-float opacity-30"></div>

      {/* Gradient Orbs */}
      <div className="absolute top-20 -left-20 w-40 h-40 bg-purple-500/10 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-20 -right-20 w-40 h-40 bg-blue-500/10 rounded-full blur-3xl animate-pulse animation-delay-1000"></div>
      <div className="absolute top-1/2 left-1/2 w-60 h-60 bg-gradient-radial from-purple-500/5 to-transparent rounded-full blur-2xl animate-pulse animation-delay-2000"></div>
    </div>
  );
};

export default AnimatedBackground;