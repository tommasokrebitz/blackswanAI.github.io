import React, { useState, useEffect } from 'react';
import { Menu, X, Zap } from 'lucide-react';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'bg-black/90 backdrop-blur-md border-b border-purple-500/20' : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-500 rounded-lg flex items-center justify-center">
              <Zap className="w-6 h-6 text-black" />
            </div>
            <span className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
              Blackswan AI
            </span>
          </div>

          <nav className="hidden md:flex items-center space-x-8">
            <a href="#services" className="text-white hover:text-purple-400 transition-colors duration-300">Services</a>
            <a href="#why-us" className="text-white hover:text-purple-400 transition-colors duration-300">Why Us</a>
            <a href="#contact" className="text-white hover:text-purple-400 transition-colors duration-300">Contact</a>
            <button 
              onClick={() => window.location.href = 'mailto:tommaso.krebitz@gmail.com?subject=Get Started with AI Automation&body=Hi, I would like to get started with AI automation for my business.'}
              className="px-6 py-2 border-2 border-purple-500 text-purple-400 hover:bg-purple-500 hover:text-white transition-all duration-300 rounded-lg neon-glow"
            >
              Get Started
            </button>
          </nav>

          <button 
            className="md:hidden text-white"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {isMobileMenuOpen && (
          <div className="md:hidden bg-black/95 backdrop-blur-md border-t border-purple-500/20">
            <nav className="px-6 py-4 space-y-4">
              <a href="#services" className="block text-white hover:text-purple-400 transition-colors duration-300">Services</a>
              <a href="#why-us" className="block text-white hover:text-purple-400 transition-colors duration-300">Why Us</a>
              <a href="#contact" className="block text-white hover:text-purple-400 transition-colors duration-300">Contact</a>
              <button 
                onClick={() => window.location.href = 'mailto:tommaso.krebitz@gmail.com?subject=Get Started with AI Automation&body=Hi, I would like to get started with AI automation for my business.'}
                className="w-full px-6 py-2 border-2 border-purple-500 text-purple-400 hover:bg-purple-500 hover:text-white transition-all duration-300 rounded-lg"
              >
                Get Started
              </button>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;