import React from 'react';
import { Clock, TrendingDown, AlertCircle, Zap, Bot, BarChart3, Settings } from 'lucide-react';

const ProblemSolution = () => {
  const problems = [
    { icon: Clock, text: 'Hours wasted on repetitive tasks' },
    { icon: TrendingDown, text: 'Missed opportunities slip by' },
    { icon: AlertCircle, text: 'Data buried in chaos' }
  ];

  const solutions = [
    { icon: Zap, text: 'Automate repetitive workflows in minutes' },
    { icon: Bot, text: 'Enhance customer engagement 24/7' },
    { icon: BarChart3, text: 'Turn raw data into actionable insights' },
    { icon: Settings, text: 'Custom AI solutions for your needs' }
  ];

  return (
    <section className="py-24 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Problem Side */}
          <div className="space-y-8">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-8">
              Slow processes?{' '}
              <span className="text-purple-400 neon-text">Missed opportunities?</span>
            </h2>
            <p className="text-xl text-gray-300 mb-8">
              We've got you covered.
            </p>
            
            <div className="space-y-6">
              {problems.map((problem, index) => (
                <div key={index} className="flex items-center space-x-4 text-red-400">
                  <problem.icon className="w-6 h-6 flex-shrink-0" />
                  <span className="text-lg">{problem.text}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Solution Side */}
          <div className="space-y-8">
            <h3 className="text-3xl md:text-4xl font-bold text-purple-400 neon-text mb-8">
              Transform Everything
            </h3>
            
            <div className="space-y-6">
              {solutions.map((solution, index) => (
                <div 
                  key={index} 
                  className="flex items-center space-x-4 p-4 rounded-lg border border-purple-500/20 bg-purple-500/5 hover:bg-purple-500/10 transition-all duration-300 group"
                >
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-blue-500 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                    <solution.icon className="w-6 h-6 text-white" />
                  </div>
                  <span className="text-lg text-white group-hover:text-purple-300 transition-colors duration-300">
                    {solution.text}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProblemSolution;