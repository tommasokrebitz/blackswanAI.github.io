import React from 'react';
import { Zap, Mail, Phone, MapPin, Linkedin, Twitter, Globe } from 'lucide-react';

const Footer = () => {
  return (
    <footer id="contact" className="bg-black border-t border-purple-500/20 py-16 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-blue-500 rounded-lg flex items-center justify-center">
                <Zap className="w-7 h-7 text-black" />
              </div>
              <span className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                Blackswan AI Agency
              </span>
            </div>
            <p className="text-gray-300 text-lg mb-6 max-w-md">
              Transforming businesses through intelligent automation. 
              Based in Italy, serving clients globally.
            </p>
            
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 border border-purple-500/30 rounded-lg flex items-center justify-center hover:border-purple-500 hover:bg-purple-500/10 transition-all duration-300">
                <Linkedin className="w-5 h-5 text-purple-400" />
              </a>
              <a href="#" className="w-10 h-10 border border-purple-500/30 rounded-lg flex items-center justify-center hover:border-purple-500 hover:bg-purple-500/10 transition-all duration-300">
                <Twitter className="w-5 h-5 text-purple-400" />
              </a>
              <a href="#" className="w-10 h-10 border border-purple-500/30 rounded-lg flex items-center justify-center hover:border-purple-500 hover:bg-purple-500/10 transition-all duration-300">
                <Globe className="w-5 h-5 text-purple-400" />
              </a>
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-xl font-semibold text-purple-400 mb-6">Services</h4>
            <ul className="space-y-3 text-gray-300">
              <li><a href="#" className="hover:text-purple-400 transition-colors duration-300">Workflow Automation</a></li>
              <li><a href="#" className="hover:text-purple-400 transition-colors duration-300">AI Chatbots</a></li>
              <li><a href="#" className="hover:text-purple-400 transition-colors duration-300">Predictive Analytics</a></li>
              <li><a href="#" className="hover:text-purple-400 transition-colors duration-300">Custom AI Solutions</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-xl font-semibold text-purple-400 mb-6">Contact</h4>
            <div className="space-y-4 text-gray-300">
              <div className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-purple-400" />
                <a href="mailto:tommaso.krebitz@gmail.com" className="hover:text-purple-400 transition-colors duration-300">
                  tommaso.krebitz@gmail.com
                </a>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-purple-400" />
                <a href="tel:+393319430839" className="hover:text-purple-400 transition-colors duration-300">
                  +39 331 943 0839
                </a>
              </div>
              <div className="flex items-center space-x-3">
                <MapPin className="w-5 h-5 text-purple-400" />
                <span>Italy</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-purple-500/20 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-center md:text-left mb-4 md:mb-0">
            © 2025 Blackswan AI Agency. All Rights Reserved.
          </p>
          <div className="flex space-x-6 text-sm text-gray-400">
            <a href="#" className="hover:text-purple-400 transition-colors duration-300">Privacy Policy</a>
            <a href="#" className="hover:text-purple-400 transition-colors duration-300">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;