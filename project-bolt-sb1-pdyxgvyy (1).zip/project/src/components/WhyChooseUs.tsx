import React from 'react';
import { Zap, Brain, Rocket } from 'lucide-react';

const WhyChooseUs = () => {
  return (
    <section id="why-us" className="py-24 px-6 relative overflow-hidden">
      <div className="max-w-5xl mx-auto text-center relative z-10">
        <div className="mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-purple-400 neon-text mb-8">
            The Edge We Bring
          </h2>
          
          <div className="flex items-center justify-center gap-4 mb-8">
            <Brain className="w-12 h-12 text-blue-400 animate-pulse" />
            <Zap className="w-16 h-16 text-purple-400 animate-bounce" />
            <Rocket className="w-12 h-12 text-pink-400 animate-pulse animation-delay-500" />
          </div>
        </div>

        <div className="max-w-4xl mx-auto">
          <p className="text-2xl md:text-3xl text-white leading-relaxed mb-8">
            A single innovation can{' '}
            <span className="text-purple-400 neon-text font-semibold">transform</span>{' '}
            your business.
          </p>
          
          <p className="text-xl md:text-2xl text-gray-300 mb-12">
            That's what we do —{' '}
            <span className="text-blue-400 font-semibold">speed</span>{' '}
            +{' '}
            <span className="text-purple-400 font-semibold">intelligence</span>{' '}
            ={' '}
            <span className="text-pink-400 font-semibold">impact</span>
          </p>

          <div className="grid md:grid-cols-3 gap-8 text-center">
            <div className="group">
              <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-blue-500 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:animate-spin">
                <Zap className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Lightning Fast</h3>
              <p className="text-gray-300">Deploy AI solutions in days, not months</p>
            </div>
            
            <div className="group">
              <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:animate-pulse">
                <Brain className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Smart Integration</h3>
              <p className="text-gray-300">Seamlessly blend AI with your existing systems</p>
            </div>
            
            <div className="group">
              <div className="w-20 h-20 bg-gradient-to-br from-pink-500 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:animate-bounce">
                <Rocket className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Explosive Growth</h3>
              <p className="text-gray-300">Measurable results from day one</p>
            </div>
          </div>
        </div>
      </div>

      {/* Background Animation */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 border border-purple-500/20 rounded-full animate-ping opacity-20"></div>
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-80 h-80 border border-blue-500/20 rounded-full animate-ping animation-delay-1000 opacity-20"></div>
    </section>
  );
};

export default WhyChooseUs;